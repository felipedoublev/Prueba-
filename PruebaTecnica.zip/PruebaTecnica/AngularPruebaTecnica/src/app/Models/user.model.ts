
export interface User{
    IdUser:number,
    IdPerson:number,
    Password:string,
    CreateAt:Date
}