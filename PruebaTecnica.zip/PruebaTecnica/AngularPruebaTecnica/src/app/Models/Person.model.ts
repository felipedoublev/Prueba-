
export interface Person {
    Id:number,
    Name :string ,
    Document:string,
    Email:string,
    DocumentType:string,
    CreateAt:Date
}